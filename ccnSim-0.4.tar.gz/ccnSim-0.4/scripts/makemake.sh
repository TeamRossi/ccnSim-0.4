#!/bin/sh
opp_makemake --deep -f -X  ./patch/   -X scripts/ -X networks/ -X modules/  -o ccnSim -X results/ -X ini/ -X manual/  -X doc/ -X file_routing/ -X ccn14distrib/ -X ccn14scripts/
